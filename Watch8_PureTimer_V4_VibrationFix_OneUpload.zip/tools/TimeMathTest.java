import com.watch8.contractpulse.TimeMath;
public class TimeMathTest {
    static void check(boolean okay, String title) {
        if (!okay) throw new AssertionError(title);
    }
    public static void main(String[] args) {
        long m = 60_000L;
        check(TimeMath.nextDue(12*m, 5*m) == 17*m, "5 minute starts from tap");
        check(TimeMath.nextDue(12*m, 15*m) == 27*m, "15 minute starts from tap");
        check(TimeMath.nextDue(12*m, 1*m) == 13*m, "custom one minute");
        check(TimeMath.nextDue(12*m, 999*m) == 1011*m, "custom 999 minute");
        check(TimeMath.nextAfterMissed(5*m, 16*m, 5*m) == 20*m, "skip missed loop ticks");
        check(TimeMath.nextAfterMissed(25*m, 16*m, 5*m) == 25*m, "keep future tick");
        check(TimeMath.nextAfterMissed(10*m, 10*m, 5*m) == 15*m, "next tick from due instant");
        check(TimeMath.nextAfterMissed(15*m, 47*m, 15*m) == 60*m, "15 minute repeat");
        boolean bad = false;
        try { TimeMath.nextDue(1, 0); } catch (IllegalArgumentException okay) { bad = true; }
        check(bad, "reject zero duration");
        System.out.println("PASS: 9 countdown tests");
    }
}
