package com.watch8.contractpulse;

import android.Manifest;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;
import android.media.AudioAttributes;
import android.os.VibrationAttributes;
import android.os.VibrationEffect;
import android.os.Vibrator;
import android.os.VibratorManager;
import android.util.Log;

/** Notification is optional; sound and vibration are triggered independently on every due alarm. */
public final class ReminderNotification {
    private static final String CHANNEL = "pure_timer_notice_v3";
    private ReminderNotification() {}

    public static void channels(Context ctx) {
        NotificationManager nm = (NotificationManager) ctx.getSystemService(Context.NOTIFICATION_SERVICE);
        if (nm == null) return;
        NotificationChannel channel = new NotificationChannel(
                CHANNEL, "纯计时 · 到点提醒", NotificationManager.IMPORTANCE_HIGH);
        channel.setDescription("手表到点显示通知。提示音和振动由应用独立触发，可在应用设置页开关。");
        channel.setSound(null, null); // Avoid double ringing: own alert player always plays the sound.
        channel.enableVibration(false); // Avoid double vibration: direct watch vibration below.
        channel.setLockscreenVisibility(Notification.VISIBILITY_PUBLIC);
        nm.createNotificationChannel(channel);
    }

    public static boolean permission(Context ctx) {
        return Build.VERSION.SDK_INT < 33 ||
                ctx.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)
                        == PackageManager.PERMISSION_GRANTED;
    }

    public static void alert(Context ctx, TimerEngine engine, int id) {
        if (engine.vibrate()) buzz(ctx, engine.vibrationStrength());
        channels(ctx);
        if (!permission(ctx)) return;
        NotificationManager nm = (NotificationManager) ctx.getSystemService(Context.NOTIFICATION_SERVICE);
        if (nm == null) return;
        Intent open = new Intent(ctx, MainActivity.class);
        open.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        PendingIntent content = PendingIntent.getActivity(ctx, 4800 + id, open,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        Notification note = new Notification.Builder(ctx, CHANNEL)
                .setSmallIcon(R.drawable.ic_watch)
                .setContentTitle(TimerEngine.title(id) + " · 时间到")
                .setContentText("时间到！点击打开六键计时器")
                .setCategory(Notification.CATEGORY_ALARM)
                .setPriority(Notification.PRIORITY_HIGH)
                .setVisibility(Notification.VISIBILITY_PUBLIC)
                .setContentIntent(content)
                .setAutoCancel(true)
                .setWhen(System.currentTimeMillis())
                .setShowWhen(true)
                .build();
        nm.notify(4400 + id, note);
    }

    /**
     * Wear OS alarms are often delivered while the watch app is in the background.
     * IMPORTANT: The no-attributes vibrate() overload used in V3 defaults to
     * unknown usage and can be suppressed for background apps.
     * Explicitly mark this effect as an ALARM on API 33+, and use the equivalent
     * AudioAttributes usage on older Wear OS devices.
     *
     * Returns whether Android accepted a vibration request; it cannot report
     * whether a user/system policy (DND, vibration setting, power saving) played it.
     */
    public static boolean buzz(Context context, int strength) {
        Vibrator v = null;
        try {
            if (Build.VERSION.SDK_INT >= 31) {
                VibratorManager manager = (VibratorManager)
                        context.getSystemService(Context.VIBRATOR_MANAGER_SERVICE);
                if (manager != null) v = manager.getDefaultVibrator();
            }
            if (v == null || !v.hasVibrator()) {
                v = (Vibrator) context.getSystemService(Context.VIBRATOR_SERVICE);
            }
            if (v == null || !v.hasVibrator()) {
                Log.w("PureTimer", "No usable vibrator on this watch");
                return false;
            }

            // Pulses are deliberately clear on a watch. Amplitude is only sent
            // when the motor supports it; otherwise use the on/off timing alone.
            final long[] timings;
            final int[] amplitudes;
            if (strength <= 0) {
                timings = new long[] {0, 120, 110, 120};
                amplitudes = new int[] {0, 180, 0, 180};
            } else if (strength >= 2) {
                timings = new long[] {0, 330, 100, 330, 100, 330};
                amplitudes = new int[] {0, 255, 0, 255, 0, 255};
            } else {
                timings = new long[] {0, 220, 110, 220, 110, 220};
                amplitudes = new int[] {0, 230, 0, 230, 0, 230};
            }
            VibrationEffect effect = v.hasAmplitudeControl()
                    ? VibrationEffect.createWaveform(timings, amplitudes, -1)
                    : VibrationEffect.createWaveform(timings, -1);
            if (Build.VERSION.SDK_INT >= 33) {
                v.vibrate(effect, VibrationAttributes.createForUsage(
                        VibrationAttributes.USAGE_ALARM));
            } else {
                AudioAttributes attrs = new AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_ALARM)
                        .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                        .build();
                v.vibrate(effect, attrs);
            }
            return true;
        } catch (SecurityException | IllegalArgumentException | IllegalStateException ex) {
            Log.w("PureTimer", "Alarm vibration failed", ex);
            return false;
        }
    }
}
