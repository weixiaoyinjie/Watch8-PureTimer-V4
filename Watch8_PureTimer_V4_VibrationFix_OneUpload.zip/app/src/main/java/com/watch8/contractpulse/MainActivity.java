package com.watch8.contractpulse;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RectF;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.text.InputType;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import java.util.Locale;

/** The 44mm round-screen home contains exactly six large timer buttons. */
public final class MainActivity extends Activity {
    private static final int GREEN = Color.rgb(137, 255, 151);
    private TimerEngine engine;
    private Dashboard dashboard;
    private ScrollView settingsView;
    private boolean onSettings;
    private int settingsScrollY;
    private float gestureStartX, gestureStartY;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private final Runnable tick = new Runnable() {
        @Override public void run() {
            if (!onSettings && dashboard != null) {
                dashboard.invalidate();
                handler.postDelayed(this, 900L);
            }
        }
    };

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
                WindowManager.LayoutParams.FLAG_FULLSCREEN);
        getWindow().setNavigationBarColor(Color.BLACK);
        engine = new TimerEngine(this);
        ReminderNotification.channels(this);
        showHome();
        if (Build.VERSION.SDK_INT >= 33 && !ReminderNotification.permission(this)) {
            requestPermissions(new String[] { Manifest.permission.POST_NOTIFICATIONS }, 1);
        }
    }

    @Override protected void onResume() {
        super.onResume();
        engine.rescheduleAll(false);
        handler.removeCallbacks(tick);
        if (onSettings) showSettings(); else handler.post(tick);
    }
    @Override protected void onPause() {
        handler.removeCallbacks(tick);
        super.onPause();
    }

    private int dp(float n) { return (int) (n * getResources().getDisplayMetrics().density + .5f); }

    private void showHome() {
        onSettings = false;
        settingsScrollY = 0;
        dashboard = new Dashboard();
        setContentView(dashboard);
        handler.removeCallbacks(tick);
        handler.post(tick);
    }

    private TextView text(String label, float sp, int color) {
        TextView tv = new TextView(this);
        tv.setText(label);
        tv.setTextSize(sp);
        tv.setTextColor(color);
        tv.setGravity(Gravity.CENTER);
        tv.setPadding(dp(2), dp(7), dp(2), dp(7));
        return tv;
    }

    private Button optionButton(String label, Runnable click) {
        Button button = new Button(this);
        button.setAllCaps(false);
        button.setText(label);
        button.setTextSize(14);
        button.setTextColor(GREEN);
        button.setMinimumHeight(dp(42));
        button.setOnClickListener(v -> click.run());
        return button;
    }

    private void toggleOption(LinearLayout root, String key, String title) {
        boolean active = "sound".equals(key) ? engine.sound() : engine.vibrate();
        root.addView(optionButton((active ? "✓ " : "○ ") + title, () -> {
            engine.setOption(key, !active);
            showSettings();
        }));
    }

    private void showSettings() {
        if (onSettings && settingsView != null) settingsScrollY = settingsView.getScrollY();
        handler.removeCallbacks(tick);
        onSettings = true;
        settingsView = new ScrollView(this);
        settingsView.setBackgroundColor(Color.rgb(6, 10, 10));
        settingsView.setFillViewport(true);
        settingsView.setVerticalScrollBarEnabled(false);
        LinearLayout root = new LinearLayout(this);
        root.setGravity(Gravity.CENTER_HORIZONTAL);
        root.setOrientation(LinearLayout.VERTICAL);
        int screen = getResources().getDisplayMetrics().widthPixels;
        root.setPadding(Math.round(screen * .13f), dp(14), Math.round(screen * .13f), dp(28));
        root.addView(text("纯计时 · 设置", 17, GREEN));
        root.addView(optionButton("↑ 返回六键主页", this::showHome));
        toggleOption(root, "sound", "到点提示音（默认开）");
        toggleOption(root, "vibrate", "到点振动（默认开）");
        String[] strengths = { "轻", "标准", "强" };
        root.addView(optionButton("振动强度：" + strengths[engine.vibrationStrength()], () -> {
            engine.cycleStrength(); showSettings();
        }));
        root.addView(optionButton("单独测试振动", () -> {
            boolean accepted = ReminderNotification.buzz(this, engine.vibrationStrength());
            Toast.makeText(this, accepted ? "已请求闹钟振动（若未振动，检查手表系统设置）"
                    : "未找到可用的振动器或振动请求失败", Toast.LENGTH_LONG).show();
        }));
        root.addView(optionButton("测试声音 + 振动 + 通知", () -> {
            ReminderNotification.alert(this, engine, TimerEngine.ONCE_5);
            if (engine.sound()) AlertPlayer.play(this, null);
            Toast.makeText(this, "已发出测试提醒", Toast.LENGTH_SHORT).show();
        }));
        root.addView(text("自定义计时 · 单位：分钟", 13, GREEN));
        root.addView(optionButton("单次时间：" + configured(TimerEngine.ONCE_CUSTOM),
                () -> editMinutes(TimerEngine.ONCE_CUSTOM, false)));
        root.addView(optionButton("循环时间：" + configured(TimerEngine.LOOP_CUSTOM),
                () -> editMinutes(TimerEngine.LOOP_CUSTOM, false)));
        root.addView(text("提醒授权", 14, GREEN));
        boolean notificationOk = ReminderNotification.permission(this);
        boolean exactOk = engine.exactAllowed();
        root.addView(text("通知 " + (notificationOk ? "✓" : "未允许")
                + "     准时闹钟 " + (exactOk ? "✓" : "未允许"), 11,
                notificationOk && exactOk ? GREEN : Color.rgb(255, 187, 101)));
        if (!notificationOk) root.addView(optionButton("允许通知", () -> {
            if (Build.VERSION.SDK_INT >= 33)
                requestPermissions(new String[]{ Manifest.permission.POST_NOTIFICATIONS }, 2);
        }));
        if (!exactOk) root.addView(optionButton("允许精确闹钟（建议）", this::requestExactAlarm));
        root.addView(text("声音使用手表闹钟音量。勿扰、静音、权限限制或省电模式可能阻止准点响铃；若没有精确闹钟权限，系统可能延迟计时通知。", 11,
                Color.rgb(195, 209, 190)));
        root.addView(optionButton("停止全部计时", () -> {
            new AlertDialog.Builder(this).setTitle("停止全部6个计时器？")
                    .setPositiveButton("停止", (dialog, which) -> {
                        engine.stopAll(); showHome();
                    }).setNegativeButton("取消", null).show();
        }));
        root.addView(text("首页上滑：设置；设置页下滑或返回：主页。",
                11, Color.rgb(157, 183, 163)));
        settingsView.addView(root, new ScrollView.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        setContentView(settingsView);
        settingsView.post(() -> settingsView.scrollTo(0, settingsScrollY));
    }

    private String configured(int id) {
        int minutes = engine.customMinutes(id);
        return minutes > 0 ? minutes + " 分钟" : "未设置";
    }

    private void editMinutes(int id, boolean startAfter) {
        EditText edit = new EditText(this);
        edit.setSingleLine(true);
        edit.setInputType(InputType.TYPE_CLASS_NUMBER);
        edit.setTextSize(20);
        edit.setTextColor(Color.WHITE);
        int current = engine.customMinutes(id);
        edit.setText(current > 0 ? Integer.toString(current) : "10");
        edit.setSelectAllOnFocus(true);
        edit.selectAll();
        edit.setHint("1–999");
        LinearLayout wrap = new LinearLayout(this);
        wrap.setPadding(dp(24), 0, dp(24), 0);
        wrap.addView(edit, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        AlertDialog dialog = new AlertDialog.Builder(this)
                .setTitle(TimerEngine.title(id) + " · 分钟")
                .setMessage("请输入 1–999 分钟")
                .setView(wrap)
                .setNegativeButton("取消", null)
                .setPositiveButton(startAfter ? "保存并开始" : "保存", null)
                .create();
        dialog.setOnShowListener(ignored -> dialog.getButton(AlertDialog.BUTTON_POSITIVE)
                .setOnClickListener(view -> {
                    int value;
                    try { value = Integer.parseInt(edit.getText().toString().trim()); }
                    catch (NumberFormatException ex) { value = 0; }
                    if (value < 1 || value > 999) {
                        edit.setError("请输入1–999之间的分钟数");
                        return;
                    }
                    if (engine.running(id)) engine.stop(id);
                    engine.setCustomMinutes(id, value);
                    if (startAfter) engine.start(id);
                    dialog.dismiss();
                    if (onSettings) showSettings();
                    else if (dashboard != null) dashboard.invalidate();
                }));
        dialog.show();
    }

    private void tapTimer(int id, boolean longHold) {
        if (TimerEngine.custom(id) && (longHold || engine.customMinutes(id) == 0 && !engine.running(id))) {
            editMinutes(id, true);
            return;
        }
        engine.toggle(id);
        if (dashboard != null) dashboard.invalidate();
        if (engine.running(id) && !engine.exactAllowed()) {
            Toast.makeText(this, "请到设置页允许精确闹钟", Toast.LENGTH_LONG).show();
        }
    }

    private void requestExactAlarm() {
        if (Build.VERSION.SDK_INT < 31) return;
        try {
            startActivity(new Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM,
                    Uri.parse("package:" + getPackageName())));
        } catch (RuntimeException ex) {
            Toast.makeText(this, "请在手表系统中开启‘闹钟与提醒’权限", Toast.LENGTH_LONG).show();
        }
    }

    @Override public void onRequestPermissionsResult(int code, String[] permissions, int[] results) {
        super.onRequestPermissionsResult(code, permissions, results);
        if (onSettings) showSettings();
    }

    @Override public boolean dispatchTouchEvent(MotionEvent event) {
        if (event.getActionMasked() == MotionEvent.ACTION_DOWN) {
            gestureStartX = event.getX(); gestureStartY = event.getY();
        } else if (event.getActionMasked() == MotionEvent.ACTION_UP) {
            float dx = event.getX() - gestureStartX;
            float dy = event.getY() - gestureStartY;
            float w = getResources().getDisplayMetrics().widthPixels;
            float h = getResources().getDisplayMetrics().heightPixels;
            if (Math.abs(dx) < w * .22f && Math.abs(dy) > h * .19f) {
                if (!onSettings && dy < 0) { showSettings(); return true; }
                if (onSettings && dy > 0 && settingsView != null &&
                        settingsView.getScrollY() == 0 && gestureStartY < h * .40f) {
                    showHome(); return true;
                }
            }
        }
        return super.dispatchTouchEvent(event);
    }

    @Override public void onBackPressed() {
        if (onSettings) showHome(); else super.onBackPressed();
    }

    private final class Dashboard extends View {
        private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final int outline = Color.rgb(52, 115, 67);
        private final int offBackground = Color.rgb(13, 27, 22);
        private final int onBackground = Color.rgb(18, 67, 40);
        private final int secondary = Color.rgb(166, 205, 172);
        private float downX, downY;
        private long downAt;

        Dashboard() {
            super(MainActivity.this);
            setClickable(true);
        }

        private void center(Canvas canvas, String label, float x, float y, float size,
                            int color, boolean bold) {
            paint.setColor(color);
            paint.setStyle(Paint.Style.FILL);
            paint.setTextAlign(Paint.Align.CENTER);
            paint.setTextSize(size);
            paint.setTypeface(android.graphics.Typeface.create("sans-serif",
                    bold ? android.graphics.Typeface.BOLD : android.graphics.Typeface.NORMAL));
            canvas.drawText(label, x, y - (paint.ascent() + paint.descent()) / 2, paint);
        }

        private RectF tile(int position, float w, float h) {
            int row = position / 2;
            int col = position % 2;
            float midX = (col == 0 ? .313f : .687f) * w;
            float midY = (.267f + row * .232f) * h;
            return new RectF(midX - .175f * w, midY - .109f * h,
                    midX + .175f * w, midY + .109f * h);
        }

        private String timeLeft(long at) {
            long secs = Math.max(0L, (at - System.currentTimeMillis() + 999L) / 1000L);
            return String.format(Locale.US, "%02d:%02d", secs / 60, secs % 60);
        }

        @Override protected void onDraw(Canvas canvas) {
            super.onDraw(canvas);
            float w = getWidth(), h = getHeight();
            canvas.drawColor(Color.rgb(3, 9, 7));
            center(canvas, "六键计时", w / 2, h * .105f, h * .049f, GREEN, true);
            for (int n = 0; n < TimerEngine.COUNT; n++) {
                int id = TimerEngine.DISPLAY_ORDER[n];
                RectF rect = tile(n, w, h);
                boolean active = engine.running(id);
                paint.setStyle(Paint.Style.FILL);
                paint.setColor(active ? onBackground : offBackground);
                canvas.drawRoundRect(rect, h * .032f, h * .032f, paint);
                paint.setStyle(Paint.Style.STROKE);
                paint.setStrokeWidth(Math.max(2f, w * .006f));
                paint.setColor(active ? GREEN : outline);
                canvas.drawRoundRect(rect, h * .032f, h * .032f, paint);
                paint.setStyle(Paint.Style.FILL);
                float x = rect.centerX(), y = rect.centerY();
                String first = TimerEngine.custom(id) ? "自定义" :
                        (id == TimerEngine.ONCE_5 || id == TimerEngine.LOOP_5 ? "5分钟" : "15分钟");
                String second = TimerEngine.loop(id) ? "循环" : "单次";
                center(canvas, first, x, y - h * .052f, h * .061f, GREEN, true);
                center(canvas, second, x, y + h * .014f, h * .054f, GREEN, true);
                String state = active ? timeLeft(engine.due(id)) :
                        (TimerEngine.custom(id) && engine.customMinutes(id) > 0
                                ? engine.customMinutes(id) + "分 · 开始" : "▶ 开始");
                center(canvas, state, x, y + h * .078f, h * .034f,
                        active ? GREEN : Color.rgb(177, 237, 190), active);
            }
            center(canvas, "↑ 上滑设置 · 自定义长按改时间", w / 2, h * .944f,
                    h * .031f, secondary, false);
        }

        @Override public boolean onTouchEvent(MotionEvent event) {
            if (event.getActionMasked() == MotionEvent.ACTION_DOWN) {
                downX = event.getX(); downY = event.getY();
                downAt = event.getEventTime();
                return true;
            }
            if (event.getActionMasked() == MotionEvent.ACTION_UP) {
                float w = getWidth(), h = getHeight();
                float x = event.getX(), y = event.getY();
                if (Math.abs(x - downX) > w * .085f || Math.abs(y - downY) > h * .09f) return true;
                if (y > h * .89f) { showSettings(); return true; }
                for (int n = 0; n < TimerEngine.COUNT; n++) {
                    if (tile(n, w, h).contains(x, y)) {
                        tapTimer(TimerEngine.DISPLAY_ORDER[n],
                                event.getEventTime() - downAt > 650L);
                        return true;
                    }
                }
                return true;
            }
            return true;
        }
    }
}
