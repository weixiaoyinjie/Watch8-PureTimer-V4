package com.watch8.contractpulse;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.media.AudioAttributes;
import android.media.AudioManager;
import android.media.MediaPlayer;
import android.os.Handler;
import android.os.Looper;
import java.util.concurrent.atomic.AtomicBoolean;

/** Short embedded alert WAV played on ALARM audio stream, regardless of notification channel. */
public final class AlertPlayer {
    private AlertPlayer() {}

    /** Keeps the alarm broadcast alive until playback finishes, with a 5-second safety timeout. */
    public static void play(Context ctx, BroadcastReceiver.PendingResult pendingResult) {
        Handler handler = new Handler(Looper.getMainLooper());
        MediaPlayer player = null;
        try {
            AudioAttributes attrs = new AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_ALARM)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                    .build();
            player = MediaPlayer.create(ctx, R.raw.timer_alert, attrs,
                    AudioManager.AUDIO_SESSION_ID_GENERATE);
            if (player == null) {
                if (pendingResult != null) pendingResult.finish();
                return;
            }
            final MediaPlayer alarm = player;
            final AtomicBoolean ended = new AtomicBoolean();
            final Runnable[] timeout = new Runnable[1];
            Runnable finish = () -> {
                if (!ended.compareAndSet(false, true)) return;
                if (timeout[0] != null) handler.removeCallbacks(timeout[0]);
                try { alarm.release(); } catch (RuntimeException ignored) { }
                if (pendingResult != null) pendingResult.finish();
            };
            timeout[0] = finish;
            alarm.setOnCompletionListener(mp -> finish.run());
            alarm.setOnErrorListener((mp, what, extra) -> { finish.run(); return true; });
            handler.postDelayed(timeout[0], 5000L);
            alarm.start();
        } catch (RuntimeException ex) {
            if (player != null) try { player.release(); } catch (RuntimeException ignored) { }
            if (pendingResult != null) pendingResult.finish();
        }
    }
}
