# Watch8 六键纯计时 V4（修复后台振动）

适配 Samsung Galaxy Watch8 44mm / Wear OS。只需 **手表 APK**，不需要手机端。

## 主页六个大绿字按钮

| 第一列（单次） | 第二列（循环） |
| --- | --- |
| 5分钟单次 | 5分钟循环 |
| 15分钟单次 | 15分钟循环 |
| 自定义单次 | 自定义循环 |

- 点击空闲按钮：从 **点击这一刻** 开始计时（非 K 线对齐）。
- 运行时按钮显示剩余时间；再次点击：关闭当前计时。
- 每个计时器可独立运行；循环到点后继续下一轮，单次到点后停止。
- 自定义两个按钮各自存储 1～999 分钟；首次点击输入，长按可重新编辑并启动。
- 从首页上滑或点击底部“设置”提示进入下一页。没有 K 线、行情、复查清单、预提醒。

## 两个独立快捷方式

安装后手表应用列表会声明三个入口：
1. **六键计时**：进入主页。
2. **5分循环开关**：按一下开启5分循环，再按一下关闭。
3. **15分循环开关**：按一下开启15分循环，再按一下关闭。

快捷入口不打开完整主页；短暂显示启动/停止 Toast 并提供轻触觉反馈。不同的 Wear OS 启动器可能对同一 APK 的多个应用入口采用不同呈现方式，真机中需要确认。

## V4：修复到点有声音、没有振动

- 声音和振动都**默认开启**。
- 到点由 `AlarmManager` 广播触发；振动明确采用 `VibrationAttributes.USAGE_ALARM`（Android 13+）或 `AudioAttributes.USAGE_ALARM`（旧版本），交给手表 `Vibrator`，提示音播放 APK 内置 1.18 秒 WAV（手表“闹钟”音量通道），同时发送通知。通知通道静音以避免重复铃声。即使用户未授予通知权限，直接音频及振动仍可尝试触发。
- `BroadcastReceiver.goAsync()` 保持回调存活直到音频结束或到 5 秒超时。
- 每个计时器对应独立的 `PendingIntent` + generation ID，停止后旧闹钟不会错触发。
- 声音、振动、强度、单独振动测试、综合测试提醒、通知权限、精确闹钟权限与全部停止均在第二页。
- 声明 `USE_EXACT_ALARM` 是因为本应用唯一核心功能是计时/闹钟；如果系统仍未允许精确计时，第二页可尝试手动授权 `SCHEDULE_EXACT_ALARM`。未授权时启用非精确备选计划。无论如何，Wear OS 省电、勿扰、音量等系统策略可能影响到点触发效果。

## 安装说明

与 V3 相同，V4 APK 的 `applicationId` 是 `com.watch8.puretimer`，并保持与 V3 相同的应用 ID 和设置存储，所以正常的同签名升级可保留 V3 计时设置。**注意：**不同 GitHub 仓库或全新 GitHub runner 生成的 debug 签名可能不同。若手表提示「无法安装/签名不一致」，先在 V3 停止全部计时，再卸载 V3 并安装 V4（卸载将清除旧计时状态），或使用原有签名私钥重新签名 V4。不要让两个计时器同时运行。

## 构建（方式 A：解压上传）

1. 新建空 GitHub 仓库 `Watch8-PureTimer-V4`。
2. 解压本 ZIP，把**所有文件及隐藏的 `.github` 文件夹**上传到仓库根目录。
3. 点击 `Actions` → `Build Watch8 PureTimer APK` → `Run workflow`。
4. 在本次运行底部的 Artifacts 中下载 `Watch8-PureTimer-V4-APK`，再从 ZIP 取出 `app-debug.apk` 安装到手表。

## 构建（方式 B：不解压 ZIP，只上传一个 ZIP）

1. 新建空 GitHub 仓库 `Watch8-PureTimer-V4`，**仅上传** `Watch8_PureTimer_V4_VibrationFix_OneUpload.zip` 文件。
2. 仓库中点击 `Add file` → `Create new file`，文件名填写 `.github/workflows/build-one-zip.yml`。
3. 复制本包同级提供的 `build-one-zip.yml.txt` 内容进 GitHub 编辑器并提交。
4. `Actions` 中运行 `Build Watch8 PureTimer from one ZIP`，下载 Artifact `Watch8-PureTimer-V4-APK`。

这里不包含已经编译好的新 APK；必须先由 GitHub Actions 完成 Android SDK 编译。`app-debug.apk` 这个原始附件是旧版，不包含上述新功能。

## 校验

提供 `tools/test-time-math.sh` 纯 Java 计时算法测试。Android 编译在 GitHub Actions 完成后，建议手表设置页点击一次“测试声音+振动+通知”，并分别测试 5分钟循环、15分钟循环快捷键打开、关闭及后台到时提醒。

## V4 振动排查

1. 在第二页确认「到点振动」为 ✓，振动强度选择「强」。
2. 点「单独测试振动」：这个按钮不依赖声音开关或通知授权，直接请求闹钟类型的振动。
3. 仍没有振动：在手表系统设置中检查声音与振动、勿扰与睡眠模式、节能/限制后台，确认系统本身可以振动。系统设置/设备厂商策略仍可能禁止振动，应用不能强行越过。
4. 再测试 5 分钟循环在锁屏/熄屏后的真实到期提醒。

关键修改：`ReminderNotification.buzz()` 在 Android 13+ 用 `v.vibrate(effect, VibrationAttributes.createForUsage(VibrationAttributes.USAGE_ALARM))`；旧 Wear OS 使用闹钟 `AudioAttributes` 重载。保留独立音效与现有全部计时业务逻辑。
